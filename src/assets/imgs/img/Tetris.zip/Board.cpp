﻿// src/Bang.cpp
#include "Board.hpp"
#include "Khoi.hpp"

Bang::Bang()
{
    // Khởi tạo toàn bộ lưới ô vuông về trạng thái trống (0)
    for (int Hang = 0; Hang < Bang_SoHang; ++Hang)   // số hàng
        for (int Cot = 0; Cot < Bang_SoCot; ++Cot)   // số cột
            Luoi_OVuong[Hang][Cot] = 0;
    // Duyệt hết các ô trong bảng, gán giá trị về 0, đảm bảo ban đầu bảng trống.
}

int Bang::Lay_O(int Hang, int Cot) const
{
    // Trả về trạng thái của ô tại (Hang, Cot) trong lưới Luoi_OVuong.
    //  - 0  : ô trống (không có khối)
    //  - 1–7: ô đang có một phần khối I, O, T, S, Z, J, L
    //
    // Hàm này dùng để:
    //  - Vẽ bảng: quyết định ô nào cần vẽ khối, ô nào để trống.
    //  - Kiểm tra trạng thái bảng khi debug hoặc xử lý logic khác.
    return Luoi_OVuong[Hang][Cot];
}

void Bang::Dat_O(int Hang, int Cot, int Gia_Tri)
{
    Luoi_OVuong[Hang][Cot] = Gia_Tri;
    // Dùng để gán giá trị cho một ô trên lưới trò chơi:
    //  - Gia_Tri = 0  : ô trống
    //  - Gia_Tri > 0  : ô có khối
    // Hỗ trợ các thao tác như cập nhật trạng thái ô khi khối rơi xuống hoặc khi bị xóa.
}

bool Bang::Nam_TrongBang(int Hang, int Cot) const
{
    // Kiểm tra một ô (Hang, Cot) có nằm trong phạm vi bảng hay không.
    //  - true  : ô hợp lệ, nằm trong bảng
    //  - false : ô nằm ngoài bảng (vượt biên)
    //
    // Hàm này giúp:
    //  - Tránh truy cập ngoài mảng Luoi_OVuong
    //  - Hỗ trợ kiểm tra va chạm với biên trong KiemTra_VaCham
    return (Hang >= 0 && Hang < Bang_SoHang && Cot >= 0 && Cot < Bang_SoCot);
    // Hang >= 0          : chỉ số hàng không được âm
    // Hang < Bang_SoHang : hàng phải nhỏ hơn chiều cao bảng
    // Cot  >= 0          : chỉ số cột không được âm
    // Cot  < Bang_SoCot  : cột phải nhỏ hơn chiều rộng bảng
}

//------------------------------------------------------
// Kiểm tra va chạm giữa Khoi k và bảng
//------------------------------------------------------
bool Bang::KiemTra_VaCham(const Khoi& k) const
{
    auto DanhSach_O = k.Lay_CacOVuong(); // Lấy mảng 4 ô (tọa độ local) của khối
    int Cot_Goc = k.Lay_Cot();       // cột gốc (x) của tâm khối trên bảng
    int Hang_Goc = k.Lay_Hang();      // hàng gốc (y) của tâm khối trên bảng
    // Đoạn này cho biết tâm của khối đang ở đâu trên bảng.

    for (int i = 0; i < 4; ++i) // Khối Tetris luôn gồm 4 ô vuông
    {
        int Cot_Thuc = Cot_Goc + DanhSach_O[i].x; // col = x
        int Hang_Thuc = Hang_Goc + DanhSach_O[i].y; // row = y
        // Đoạn này đang tính VỊ TRÍ THỰC TẾ của từng ô trong khối trên bảng.

        // -----------------------------------------------------------------
        // Ví dụ minh họa (giống phần giải thích trước):
        //
        //  - Cot_Goc, Hang_Goc: vị trí tâm khối trên bảng (GLOBAL)
        //  - DanhSach_O[i].x, DanhSach_O[i].y: tọa độ local (dx, dy) lệch
        //    so với tâm (0,0) của khối.
        //
        //  Công thức chuyển từ local -> global:
        //      Cot_Thuc  = Cot_Goc  + dx;
        //      Hang_Thuc = Hang_Goc + dy;
        //
        //  Sau khi có (Hang_Thuc, Cot_Thuc), ta có thể:
        //      - Kiểm tra ô đó có nằm trong bảng không (Nam_TrongBang)
        //      - Kiểm tra ô đó có trùng với ô đã có khối trong Luoi_OVuong
        // -----------------------------------------------------------------

        // Nếu khối nằm ngoài phạm vi bảng → va chạm
        if (!Nam_TrongBang(Hang_Thuc, Cot_Thuc))
            return true;
        // Đây là cách mình bảo vệ:
        //  - Khối không được xoay chui qua tường
        //  - Không được di chuyển quá trái/phải
        //  - Không được rơi xuyên qua đáy

        // Nếu ô đó đã có khối trước đó → va chạm
        if (Luoi_OVuong[Hang_Thuc][Cot_Thuc] != 0)
            return true;
        // Ví dụ:
        //         0 1 2 3 4 5 6 7 8 9
        // row 18: . . . . . . . . . .
        // row 19: . . . X X . . . . .
        // Hai ô (19,3) và (19,4) có khối (giá trị != 0).
        // Nếu khối đang rơi có một ô được tính ra (Hang_Thuc, Cot_Thuc) = (19,3)
        // thì sẽ xảy ra va chạm.
    }

    // Không có va chạm
    return false;
}

//------------------------------------------------------
// Khóa khối hiện tại vào lưới (sau khi rơi xong)
//------------------------------------------------------
void Bang::Khoa_Khoi(const Khoi& k)
{
    // Đây là hàm dùng để xác định khi khối đang rơi mà không rơi tiếp được nữa
    // (chạm đáy hoặc chồng lên khối khác), mình sẽ khóa lại.
    auto DanhSach_O = k.Lay_CacOVuong();
    int Cot_Goc = k.Lay_Cot();
    int Hang_Goc = k.Lay_Hang();

    int Id = static_cast<int>(k.Lay_Kieu()) + 1;
    // Lý do cộng +1:
    //  - Trong Luoi_OVuong, 0 dùng để biểu diễn ô trống.
    //  - Các kiểu khối (I, O, T, S, Z, J, L) ban đầu có giá trị từ 0..6.
    //  → Nếu giữ nguyên thì khối I (0) sẽ trùng với ô trống.
    //  → Ta dịch toàn bộ sang 1..7 để phân biệt rõ:
    //      1..7: các loại khối I..L
    //      0   : ô trống

    for (int i = 0; i < 4; ++i)
    {
        int Cot_Thuc = Cot_Goc + DanhSach_O[i].x;
        int Hang_Thuc = Hang_Goc + DanhSach_O[i].y;
        // Tính vị trí thực tế của từng ô trên bảng.
        // DanhSach_O[i].x, .y là tọa độ local (dx, dy) lệch so với tâm (0,0).

        if (Nam_TrongBang(Hang_Thuc, Cot_Thuc))
        {
            // Nếu tọa độ hợp lệ thì gán Id = 1..7 → tượng trưng cho loại khối.
            // Từ giờ ô này được coi là gạch cố định trên bảng.
            Luoi_OVuong[Hang_Thuc][Cot_Thuc] = Id;
        }
    }

    // TODO (Nguyễn Tiến Đạt – Âm thanh + hiệu ứng nổ):
    //      Gọi hàm phát âm thanh / hiệu ứng hạt khi một khối được khóa xuống.
}

//------------------------------------------------------
// Xóa các hàng đầy và dồn những hàng phía trên xuống
//------------------------------------------------------
int Bang::Xoa_DongDay()
{
    int So_DongXoa = 0; // biến đếm số dòng đã xóa

    // Duyệt từ hàng dưới cùng lên trên
    for (int Hang = Bang_SoHang - 1; Hang >= 0; --Hang)
    {
        bool Day_Du = true; // giả sử dòng này đầy

        // Kiểm tra dòng này có đầy hay không
        for (int Cot = 0; Cot < Bang_SoCot; ++Cot)
        {
            if (Luoi_OVuong[Hang][Cot] == 0) // nếu có ô trống
            {
                Day_Du = false;
                break; // thoát vòng for cột, tiết kiệm thời gian
            }
        }

        if (Day_Du)
        {
            // Dồn các dòng phía trên xuống một hàng
            for (int Hang_Dich = Hang; Hang_Dich > 0; --Hang_Dich)
            {
                for (int Cot = 0; Cot < Bang_SoCot; ++Cot)
                {
                    Luoi_OVuong[Hang_Dich][Cot] = Luoi_OVuong[Hang_Dich - 1][Cot];
                }
            }

            // Dòng trên cùng gán 0 (trống)
            for (int Cot = 0; Cot < Bang_SoCot; ++Cot)
            {
                Luoi_OVuong[0][Cot] = 0;
            }

            ++So_DongXoa; // tăng biến đếm số dòng đã xóa
            ++Hang;       // kiểm tra lại dòng vừa kéo xuống

            // Giải thích ++Hang:
            // Giả sử:
            //  Hang 1: . . . . .
            //  Hang 2: . . . . .
            //  Hang 3: . X . X .
            //  Hang 4: X X X X X (FULL)
            //  Hang 5: X X X X X (FULL)
            //
            // Khi xét Hang = 5 (FULL) và xóa:
            //  - Kéo Hang 4 xuống thành Hang 5,
            //  - Các hàng phía trên dịch xuống tương ứng.
            //
            // Sau khi kéo:
            //  Hang 1: . . . . .
            //  Hang 2: . . . . .
            //  Hang 3: . . . . .
            //  Hang 4: . X . X .
            //  Hang 5: X X X X X (FULL)  ← chính là hàng cũ ở trên
            //
            // Nếu không ++Hang, vòng for sẽ tiếp tục Hang--,
            // bỏ qua việc kiểm tra lại hàng mới ở vị trí này.
        }
    }

    // TODO (Châu Gia Lương – Lưu trữ + điểm cao):
    //      Dùng giá trị So_DongXoa để:
    //        - Cộng điểm, tăng level, combo...
    //        - Cập nhật và lưu high score (nếu cần).
    return So_DongXoa;
}

//------------------------------------------------------
// Tính khoảng cách khối có thể rơi thêm trước khi va chạm
//------------------------------------------------------
int Bang::Tinh_KhoangCachRoi(const Khoi& k) const
{
    Khoi Tam = k;      // Sao chép khối hiện tại thành một bản tạm để thử rơi
    int KhoangCach = 0; // Khối rơi được bao nhiêu hàng trước khi đụng

    while (true)
    {
        Tam.Di_Chuyen(0, 1); // thử rơi xuống 1 hàng

        if (KiemTra_VaCham(Tam))
        {
            // Vị trí này đã va chạm → dừng
            break;
        }

        ++KhoangCach;
    }

    return KhoangCach;
}

//------------------------------------------------------
// Vị trí Y của ghost piece (bóng của khối)
//------------------------------------------------------
int Bang::Tinh_YBongMa(const Khoi& k) const
{
    // ghostY là tọa độ Y cuối cùng của khối nếu thả rơi tự do
    // = vị trí hàng hiện tại của khối + khoảng cách có thể rơi thêm
    int Y_BongMa = k.Lay_Hang() + Tinh_KhoangCachRoi(k);

    // TODO (Trần Phú Thành – Vẽ giao diện + Theme):
    //      Dùng Y_BongMa (kết hợp với k.Lay_Cot() và k.Lay_CacOVuong())
    //      để vẽ "bóng" của khối (ghost piece) trên màn hình
    //      với màu mờ hơn khối chính.
    return Y_BongMa;
}
