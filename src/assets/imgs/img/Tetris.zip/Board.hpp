﻿// File: Bang.hpp
#pragma once
#include "CauHinh.hpp"
#include "Khoi.hpp"

// Lớp Bang quản lý bảng Tetris, bao gồm lưới ô vuông và các thao tác trên bảng
class Bang {
public:
    Bang(); // Khởi tạo bảng, thiết lập toàn bộ ô về trạng thái trống

    int  Lay_O(int Hang, int Cot) const;
    // Lấy giá trị của ô tại vị trí (Hang, Cot)

    void Dat_O(int Hang, int Cot, int Gia_Tri);
    // Đặt giá trị cho ô tại vị trí (Hang, Cot)

    bool Nam_TrongBang(int Hang, int Cot) const;
    // Kiểm tra xem tọa độ (Hang, Cot) có nằm trong bảng hay không

    bool KiemTra_VaCham(const Khoi& k) const;
    // Kiểm tra xem khối k có va chạm với bảng hoặc các khối đã khóa hay không

    void Khoa_Khoi(const Khoi& k);
    // Khóa khối k vào bảng (khi nó chạm đáy hoặc chồng lên khối khác)

    int  Xoa_DongDay();
    // Xóa các dòng đã đầy và trả về số dòng đã xóa

    int  Tinh_KhoangCachRoi(const Khoi& k) const;
    // Tính khoảng cách khối k có thể rơi tự do trước khi va chạm

    int  Tinh_YBongMa(const Khoi& k) const;
    // Tính tọa độ Y của "bóng ma": vị trí cuối cùng mà khối k sẽ rơi xuống nếu thả tự do

private:
    int Luoi_OVuong[Bang_SoHang][Bang_SoCot];
    // Lưới ô vuông của bảng, lưu trạng thái mỗi ô
    // 0  = ô trống
    // >0 = ô đang có một phần của khối
};
