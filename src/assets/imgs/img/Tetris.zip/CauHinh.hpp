﻿#pragma once

// ----------------------
// Cấu hình bảng Tetris
// ----------------------

// Số cột trong bảng Tetris
constexpr int Bang_SoCot = 10;

// Số hàng trong bảng Tetris
constexpr int Bang_SoHang = 20;

// Kích thước mỗi ô vuông (pixel)
constexpr int Kich_ThuocO = 30;


// ----------------------
// Kiểu khối Tetris
// ----------------------
// Dùng để nhận dạng đây là loại khối nào, dùng chung trong nhiều file
enum class KieuKhoi
{
    I = 0, // = 0
    O,     // = 1
    T,     // = 2
    S,     // = 3
    Z,     // = 4
    J,     // = 5
    L      // = 6
};


// ----------------------
// Độ khó trò chơi
// ----------------------

enum class DoKho
{
    De = 0,  // Chế độ dễ
    Vua,     // Chế độ vừa (mặc định)
    Kho      // Chế độ khó
};
