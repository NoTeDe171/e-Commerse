﻿// src/main.cpp

#include <SFML/Graphics.hpp>
#include <cstdlib>
#include <ctime>

#include "Board.hpp"
#include "Khoi.hpp"
#include "CauHinh.hpp"

// ----------------------
// Random kiểu khối
// ----------------------
// Hàm random kiểu khối KieuKhoi (I, O, T, S, Z, J, L)
static KieuKhoi Random_KieuKhoi()
{
    int r = std::rand() % 7;
    // r nằm trong khoảng 0..6, tương ứng với các giá trị enum KieuKhoi
    return static_cast<KieuKhoi>(r);
}

// ----------------------
// Cấu hình độ khó
// ----------------------
struct CauHinh_DoKho
{
    float ThoiGian_RoiTuDong; // số giây giữa mỗi lần khối tự rơi 1 ô
};

// Hàm trả về cấu hình theo độ khó
CauHinh_DoKho Lay_CauHinh_DoKho(DoKho doKho)
{
    switch (doKho)
    {
    case DoKho::De:
        // Dễ: rơi chậm, phù hợp người mới
        return CauHinh_DoKho{ 0.8f };
    case DoKho::Vua:
        // Vừa: tốc độ trung bình
        return CauHinh_DoKho{ 0.5f };
    case DoKho::Kho:
        // Khó: rơi nhanh, thử thách hơn
        return CauHinh_DoKho{ 0.3f };
    default:
        return CauHinh_DoKho{ 0.5f };
    }
}

int main()
{
    std::srand(static_cast<unsigned int>(std::time(nullptr)));
    // Khởi tạo random cho toàn chương trình
    // → Mỗi lần mở game sẽ có chuỗi khối khác nhau.

    sf::RenderWindow CuaSo(sf::VideoMode(800, 600), "TetrisNewState");
    // Tạo cửa sổ 800x600 để vẽ bảng, khối, UI...
    CuaSo.setFramerateLimit(60);
    // Game loop chạy tối đa ~60 FPS → mượt và ổn định.

    Bang Bang_Chinh;

    Khoi Khoi_DangRoi;   // Khối đang rơi
    Khoi Khoi_TiepTheo;  // Khối sẽ xuất hiện tiếp theo

    // ----------------------
    // Độ khó hiện tại
    // ----------------------
    // Các mức hiện có:
    //   - DoKho::De  → rơi chậm, cho người mới
    //   - DoKho::Vua → rơi vừa, mặc định
    //   - DoKho::Kho → rơi nhanh, thử thách hơn
    DoKho DoKho_HienTai = DoKho::Vua;

    // TODO[SV_GameLogic]:
    //   - Sau này có menu chọn độ khó, hãy cập nhật DoKho_HienTai tại đó
    //     (ví dụ: phím 1 = De, 2 = Vua, 3 = Kho).

    // Lấy cấu hình ứng với độ khó hiện tại
    CauHinh_DoKho CauHinhHienTai = Lay_CauHinh_DoKho(DoKho_HienTai);

    // Thời gian rơi tự động (giây), phụ thuộc độ khó
    float ThoiGian_RoiTuDong = CauHinhHienTai.ThoiGian_RoiTuDong;
    sf::Clock DongHo_RoiTuDong;

    // Khởi tạo khối tiếp theo ban đầu
    KieuKhoi Kieu_TiepTheo = Random_KieuKhoi();
    Khoi_TiepTheo.Dat_Lai(Kieu_TiepTheo);

    // Hàm sinh khối mới từ khối "tiep theo"
    auto Sinh_KhoiMoi = [&]()
        {
            // Khoi_DangRoi nhận kiểu/hình dạng từ Khoi_TiepTheo
            Khoi_DangRoi.Dat_Lai(Kieu_TiepTheo);
            Khoi_DangRoi.Dat_ViTri(Bang_SoCot / 2, 0);

            // Random kiểu mới cho Khoi_TiepTheo
            Kieu_TiepTheo = Random_KieuKhoi();
            Khoi_TiepTheo.Dat_Lai(Kieu_TiepTheo);
        };

    // Gọi 1 lần lúc bắt đầu game
    Sinh_KhoiMoi();

    bool GameOver = false; // Trạng thái game over

    // Hình vuông dùng để vẽ từng ô trên bảng
    sf::RectangleShape O_Ve(sf::Vector2f(Kich_ThuocO - 1, Kich_ThuocO - 1));
    // Trừ 1 pixel để tạo khoảng cách giữa các ô

    // Canh giữa bảng trong cửa sổ 800x600
    const int LechX_Bang = (800 - Bang_SoCot * Kich_ThuocO) / 2;
    const int LechY_Bang = (600 - Bang_SoHang * Kich_ThuocO) / 2;

    // Vị trí ô "NEXT" (khối tiếp theo) nằm bên phải bảng
    const int ViTri_HopNext_X = LechX_Bang + Bang_SoCot * Kich_ThuocO + 40; // cách bảng 40 pixel
    const int ViTri_HopNext_Y = LechY_Bang + 40;                             // cách trên 40 pixel

    // TODO (Châu Gia Lương – Lưu trữ + điểm cao):
    //      Thêm biến:
    //          int Diem = 0;
    //          int DiemCao = 0;
    //      Và hàm load/save high score từ file.

    while (CuaSo.isOpen())
    {
        sf::Event SuKien;
        while (CuaSo.pollEvent(SuKien))
        {
            if (SuKien.type == sf::Event::Closed)
                CuaSo.close();

            // Xử lý phím bấm
            if (SuKien.type == sf::Event::KeyPressed)
            {
                // TODO (Lê Quang Minh – Điều khiển + Menu):
                //      Thêm phím mở menu, pause, restart, đổi độ khó, ...

                if (!GameOver)
                {
                    // Di chuyển khối sang trái
                    if (SuKien.key.code == sf::Keyboard::Left)
                    {
                        Khoi Khoi_Thu = Khoi_DangRoi;
                        Khoi_Thu.Di_Chuyen(-1, 0);

                        if (!Bang_Chinh.KiemTra_VaCham(Khoi_Thu))
                            Khoi_DangRoi = Khoi_Thu;
                    }

                    // Di chuyển khối sang phải
                    if (SuKien.key.code == sf::Keyboard::Right)
                    {
                        Khoi Khoi_Thu = Khoi_DangRoi;
                        Khoi_Thu.Di_Chuyen(1, 0);

                        if (!Bang_Chinh.KiemTra_VaCham(Khoi_Thu))
                            Khoi_DangRoi = Khoi_Thu;
                    }

                    // Xoay khối
                    if (SuKien.key.code == sf::Keyboard::Up)
                    {
                        Khoi Khoi_Thu = Khoi_DangRoi;
                        Khoi_Thu.Quay_CungChieuKim();

                        if (!Bang_Chinh.KiemTra_VaCham(Khoi_Thu))
                        {
                            Khoi_DangRoi = Khoi_Thu;
                            // TODO (Nguyễn Tiến Đạt – Âm thanh + hiệu ứng nổ):
                            //      Phát âm thanh xoay khối tại đây.
                        }
                    }

                    // Rơi nhanh 1 ô khi nhấn phím xuống
                    if (SuKien.key.code == sf::Keyboard::Down)
                    {
                        Khoi Khoi_Thu = Khoi_DangRoi;
                        Khoi_Thu.Di_Chuyen(0, 1);

                        if (Bang_Chinh.KiemTra_VaCham(Khoi_Thu))
                        {
                            // Không rơi được nữa → khóa khối
                            Bang_Chinh.Khoa_Khoi(Khoi_DangRoi);
                            int So_DongXoa = Bang_Chinh.Xoa_DongDay();

                            // TODO (Châu Gia Lương – Lưu trữ + điểm cao):
                            //      Dùng So_DongXoa để cộng điểm + cập nhật high score.

                            // TODO (Nguyễn Tiến Đạt – Âm thanh + hiệu ứng nổ):
                            //      Phát âm thanh clear line tùy theo số dòng.

                            // Sinh khối mới từ "tiep theo"
                            Sinh_KhoiMoi();

                            // Nếu vừa spawn đã va chạm → game over
                            if (Bang_Chinh.KiemTra_VaCham(Khoi_DangRoi))
                            {
                                GameOver = true;
                                // TODO (Nguyễn Tiến Đạt – Âm thanh + hiệu ứng nổ):
                                //      Phát âm thanh game over.
                            }
                        }
                        else
                        {
                            Khoi_DangRoi = Khoi_Thu;
                        }

                        DongHo_RoiTuDong.restart();
                    }

                    // Hard drop: Space
                    if (SuKien.key.code == sf::Keyboard::Space)
                    {
                        int KhoangCach = Bang_Chinh.Tinh_KhoangCachRoi(Khoi_DangRoi);
                        Khoi_DangRoi.Di_Chuyen(0, KhoangCach);

                        Bang_Chinh.Khoa_Khoi(Khoi_DangRoi);
                        int So_DongXoa = Bang_Chinh.Xoa_DongDay();

                        // TODO (Châu Gia Lương – Lưu trữ + điểm cao):
                        //      Cộng điểm bonus cho hard drop (nếu muốn).

                        // TODO (Nguyễn Tiến Đạt – Âm thanh + hiệu ứng nổ):
                        //      Âm thanh rơi mạnh + clear line.

                        Sinh_KhoiMoi();
                        if (Bang_Chinh.KiemTra_VaCham(Khoi_DangRoi))
                        {
                            GameOver = true;
                            // TODO (Nguyễn Tiến Đạt – Âm thanh + hiệu ứng nổ):
                            //      Âm thanh game over.
                        }

                        DongHo_RoiTuDong.restart();
                    }
                }
                else
                {
                    // Khi game over:
                    // TODO (Lê Quang Minh – Điều khiển + Menu):
                    //      Dùng phím R để restart game, v.v.
                }
            }
        }

        // ----------------------
        // Logic rơi tự động
        // ----------------------
        if (!GameOver && DongHo_RoiTuDong.getElapsedTime().asSeconds() >= ThoiGian_RoiTuDong)
        {
            Khoi Khoi_Thu = Khoi_DangRoi;
            Khoi_Thu.Di_Chuyen(0, 1);

            if (Bang_Chinh.KiemTra_VaCham(Khoi_Thu))
            {
                Bang_Chinh.Khoa_Khoi(Khoi_DangRoi);
                int So_DongXoa = Bang_Chinh.Xoa_DongDay();

                // TODO (Châu Gia Lương – Lưu trữ + điểm cao):
                //      Cộng điểm dựa trên So_DongXoa.

                // TODO (Nguyễn Tiến Đạt – Âm thanh + hiệu ứng nổ):
                //      Âm thanh lock khối / clear line.

                Sinh_KhoiMoi();
                if (Bang_Chinh.KiemTra_VaCham(Khoi_DangRoi))
                {
                    GameOver = true;
                    // TODO (Nguyễn Tiến Đạt – Âm thanh + hiệu ứng nổ):
                    //      Âm thanh game over.
                }
            }
            else
            {
                Khoi_DangRoi = Khoi_Thu;
            }

            DongHo_RoiTuDong.restart();
        }

        // ==========================
        // PHẦN VẼ (render)
        // ==========================
        CuaSo.clear();

        // -------- Vẽ các ô đã khóa trên bảng --------
        for (int Hang = 0; Hang < Bang_SoHang; ++Hang)
        {
            for (int Cot = 0; Cot < Bang_SoCot; ++Cot)
            {
                int Id = Bang_Chinh.Lay_O(Hang, Cot);
                if (Id != 0)
                {
                    O_Ve.setPosition(
                        LechX_Bang + Cot * Kich_ThuocO,
                        LechY_Bang + Hang * Kich_ThuocO
                    );

                    switch (Id)
                    {
                    case 1: O_Ve.setFillColor(sf::Color::Cyan);    break; // I
                    case 2: O_Ve.setFillColor(sf::Color::Yellow);  break; // O
                    case 3: O_Ve.setFillColor(sf::Color::Magenta); break; // T
                    case 4: O_Ve.setFillColor(sf::Color::Green);   break; // S
                    case 5: O_Ve.setFillColor(sf::Color::Red);     break; // Z
                    case 6: O_Ve.setFillColor(sf::Color::Blue);    break; // J
                    case 7: O_Ve.setFillColor(sf::Color(255, 165, 0)); break; // L
                    default: O_Ve.setFillColor(sf::Color::White);  break;
                    }

                    CuaSo.draw(O_Ve);
                }
            }
        }

        // -------- Vẽ ghost piece (bóng khối) --------
        {
            int Y_BongMa = Bang_Chinh.Tinh_YBongMa(Khoi_DangRoi);
            auto DanhSach_OVuong = Khoi_DangRoi.Lay_CacOVuong();
            int Cot_Goc = Khoi_DangRoi.Lay_Cot();

            O_Ve.setFillColor(sf::Color(255, 255, 255, 60)); // màu mờ

            for (int i = 0; i < 4; ++i)
            {
                int Cot_Thuc = Cot_Goc + DanhSach_OVuong[i].x;
                int Hang_Thuc = Y_BongMa + DanhSach_OVuong[i].y;

                O_Ve.setPosition(
                    LechX_Bang + Cot_Thuc * Kich_ThuocO,
                    LechY_Bang + Hang_Thuc * Kich_ThuocO
                );

                CuaSo.draw(O_Ve);
            }
        }

        // -------- Vẽ khối đang rơi --------
        {
            auto DanhSach_OVuong = Khoi_DangRoi.Lay_CacOVuong();
            int Cot_Goc = Khoi_DangRoi.Lay_Cot();
            int Hang_Goc = Khoi_DangRoi.Lay_Hang();

            sf::Color Mau = sf::Color::White;
            switch (Khoi_DangRoi.Lay_Kieu())
            {
            case KieuKhoi::I: Mau = sf::Color::Cyan;    break;
            case KieuKhoi::O: Mau = sf::Color::Yellow;  break;
            case KieuKhoi::T: Mau = sf::Color::Magenta; break;
            case KieuKhoi::S: Mau = sf::Color::Green;   break;
            case KieuKhoi::Z: Mau = sf::Color::Red;     break;
            case KieuKhoi::J: Mau = sf::Color::Blue;    break;
            case KieuKhoi::L: Mau = sf::Color(255, 165, 0); break;
            }

            O_Ve.setFillColor(Mau);

            for (int i = 0; i < 4; ++i)
            {
                int Cot_Thuc = Cot_Goc + DanhSach_OVuong[i].x;
                int Hang_Thuc = Hang_Goc + DanhSach_OVuong[i].y;

                O_Ve.setPosition(
                    LechX_Bang + Cot_Thuc * Kich_ThuocO,
                    LechY_Bang + Hang_Thuc * Kich_ThuocO
                );

                CuaSo.draw(O_Ve);
            }
        }

        // -------- Vẽ khối NEXT (sẽ xuất hiện tiếp theo) --------
        {
            auto DanhSach_OVuong_Next = Khoi_TiepTheo.Lay_CacOVuong();

            sf::Color Mau = sf::Color::White;
            switch (Khoi_TiepTheo.Lay_Kieu())
            {
            case KieuKhoi::I: Mau = sf::Color::Cyan;    break;
            case KieuKhoi::O: Mau = sf::Color::Yellow;  break;
            case KieuKhoi::T: Mau = sf::Color::Magenta; break;
            case KieuKhoi::S: Mau = sf::Color::Green;   break;
            case KieuKhoi::Z: Mau = sf::Color::Red;     break;
            case KieuKhoi::J: Mau = sf::Color::Blue;    break;
            case KieuKhoi::L: Mau = sf::Color(255, 165, 0); break;
            }

            O_Ve.setFillColor(Mau);

            // Dịch các ô vào trong một ô 4x4 ở góc phải
            for (int i = 0; i < 4; ++i)
            {
                int Cot_Ve = DanhSach_OVuong_Next[i].x + 2; // +2 để canh giữa trong ô 4x4
                int Hang_Ve = DanhSach_OVuong_Next[i].y + 2;

                O_Ve.setPosition(
                    ViTri_HopNext_X + Cot_Ve * Kich_ThuocO,
                    ViTri_HopNext_Y + Hang_Ve * Kich_ThuocO
                );

                CuaSo.draw(O_Ve);
            }

            // TODO (Trần Phú Thành – Vẽ giao diện + Theme):
            //      Vẽ khung chữ "NEXT" và viền hộp preview đẹp hơn.
        }

        // TODO (Trần Phú Thành – Vẽ giao diện + Theme):
        //      Vẽ thêm:
        //        - Khung bảng
        //        - Lưới mờ
        //        - Score, High score, Level
        //        - Thông báo "Game Over" nếu GameOver == true

        CuaSo.display();
    }

    return 0;
}
