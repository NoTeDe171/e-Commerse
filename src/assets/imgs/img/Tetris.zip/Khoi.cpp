﻿// src/Khoi.cpp
// Logic khối Tetris

#include "Khoi.hpp"

Khoi::Khoi()
{
    Dat_Lai(KieuKhoi::I);
    // Constructor không tham số mặc định tạo khối I.
    // Đảm bảo đối tượng Khoi luôn có một trạng thái hợp lệ khi được khởi tạo.
    // Dù mình chưa chọn loại khối nào thì vẫn là một khối I an toàn.
}

Khoi::Khoi(KieuKhoi Kieu_BanDau)
{
    Dat_Lai(Kieu_BanDau);
    // Constructor có tham số nhận kiểu khối ban đầu,
    // Kieu_BanDau là biến tạm chỉ tồn tại trong hàm này.
}

//------------------------------------------------------
// Tái khởi tạo khối (spawn khối mới)
//------------------------------------------------------
void Khoi::Dat_Lai(KieuKhoi Kieu_Moi)
{
    Kieu = Kieu_Moi; // Lưu kiểu khối hiện tại

    // Spawn khối ở giữa bảng, trên đỉnh
    Cot = Bang_SoCot / 2;
    Hang = 0;

    TrangThai_Xoay = 0;   // Trạng thái xoay ban đầu
    KhoiTao_HinhDang();   // Khởi tạo hình dạng theo loại khối

    // TODO (Trần Phú Thành – Vẽ giao diện + Theme):
    //      Có thể dùng Kieu để quyết định màu sắc/theme
    //      trong lớp vẽ (Render), ví dụ:
    //      - I: xanh dương
    //      - O: vàng
    //      - T: tím
}

//------------------------------------------------------
// Vị trí
//------------------------------------------------------
void Khoi::Dat_ViTri(int Cot_Moi, int Hang_Moi)
{
    Cot = Cot_Moi;
    Hang = Hang_Moi;
    // Thiết lập vị trí gốc (tâm) của khối trên bảng
}

void Khoi::Di_Chuyen(int Delta_Cot, int Delta_Hang)
{
    Cot += Delta_Cot;  // Dịch ngang theo cột
    Hang += Delta_Hang; // Dịch dọc theo hàng
}

//------------------------------------------------------
// Khởi tạo hình dạng ban đầu cho từng loại khối
// (tọa độ local x, y xoay quanh tâm (0,0))
//------------------------------------------------------
void Khoi::KhoiTao_HinhDang()
{
    // Mặc định: tất cả ô đều tại (0,0)
    for (int i = 0; i < 4; ++i)
    {
        DanhSach_OVuong[i].x = 0;
        DanhSach_OVuong[i].y = 0;
    }

    switch (Kieu)
    {
    case KieuKhoi::I:
        // I: ----   (nằm ngang qua tâm)
        //  [ -2,0 ], [ -1,0 ], [ 0,0 ], [ 1,0 ]
        DanhSach_OVuong[0] = { -2, 0 };
        DanhSach_OVuong[1] = { -1, 0 };
        DanhSach_OVuong[2] = { 0, 0 };
        DanhSach_OVuong[3] = { 1, 0 };
        break;

    case KieuKhoi::O:
        // O: hình vuông 2x2
        //   [0,0] [1,0]
        //   [0,1] [1,1]
        DanhSach_OVuong[0] = { 0, 0 };
        DanhSach_OVuong[1] = { 1, 0 };
        DanhSach_OVuong[2] = { 0, 1 };
        DanhSach_OVuong[3] = { 1, 1 };
        break;

    case KieuKhoi::T:
        // T:
        //   [-1,0] [0,0] [1,0]
        //          [0,1]
        DanhSach_OVuong[0] = { 0, 0 }; // tâm
        DanhSach_OVuong[1] = { -1, 0 };
        DanhSach_OVuong[2] = { 1, 0 };
        DanhSach_OVuong[3] = { 0, 1 };
        break;

    case KieuKhoi::S:
        // S:
        //        [0,0] [1,0]
        //   [-1,1] [0,1]
        DanhSach_OVuong[0] = { 0, 0 };
        DanhSach_OVuong[1] = { 1, 0 };
        DanhSach_OVuong[2] = { -1, 1 };
        DanhSach_OVuong[3] = { 0, 1 };
        break;

    case KieuKhoi::Z:
        // Z:
        //   [-1,0] [0,0]
        //         [0,1] [1,1]
        DanhSach_OVuong[0] = { -1, 0 };
        DanhSach_OVuong[1] = { 0, 0 };
        DanhSach_OVuong[2] = { 0, 1 };
        DanhSach_OVuong[3] = { 1, 1 };
        break;

    case KieuKhoi::J:
        // J:
        //   [-1,0] [0,0] [1,0]
        //                [1,1]
        DanhSach_OVuong[0] = { 0, 0 };
        DanhSach_OVuong[1] = { -1, 0 };
        DanhSach_OVuong[2] = { 1, 0 };
        DanhSach_OVuong[3] = { 1, 1 };
        break;

    case KieuKhoi::L:
        // L:
        //   [-1,0] [0,0] [1,0]
        //   [-1,1]
        DanhSach_OVuong[0] = { 0, 0 };
        DanhSach_OVuong[1] = { -1, 0 };
        DanhSach_OVuong[2] = { 1, 0 };
        DanhSach_OVuong[3] = { -1, 1 };
        break;
    }

    // TODO (Trần Phú Thành – Vẽ giao diện + Theme):
    //      Khi vẽ khối trên màn hình, dùng:
    //        - DanhSach_OVuong (dx, dy) + Cot, Hang
    //      để tính ra vị trí từng ô trên bảng và gán màu theo Kieu.
}

//------------------------------------------------------
// Xoay toàn bộ 4 ô theo chiều kim đồng hồ 90 độ
// quanh gốc (0,0) bằng phép biến đổi:
//    (x, y) → (y, -x)
//------------------------------------------------------
void Khoi::ApDung_QuayCungChieuKim()
{
    for (int i = 0; i < 4; ++i)
    {
        int X_Cu = DanhSach_OVuong[i].x;
        int Y_Cu = DanhSach_OVuong[i].y;
        // Lưu lại tọa độ cũ

        int X_Moi = Y_Cu;
        int Y_Moi = -X_Cu;
        // Công thức xoay 90 độ theo chiều kim đồng hồ

        DanhSach_OVuong[i].x = X_Moi;
        DanhSach_OVuong[i].y = Y_Moi;
        // Cập nhật tọa độ sau khi xoay
    }
}

//------------------------------------------------------
// Thực hiện xoay khối theo chiều kim đồng hồ
//  - Cập nhật TrangThai_Xoay (0..3)
//  - Áp dụng biến đổi tọa độ local
//------------------------------------------------------
void Khoi::Quay_CungChieuKim()
{
    TrangThai_Xoay = (TrangThai_Xoay + 1) % 4; // Nếu vượt quá 3 thì quay về 0
    ApDung_QuayCungChieuKim();

    // TODO (Nguyễn Tiến Đạt – Âm thanh + hiệu ứng nổ):
    //      Trong game loop, sau khi gọi Quay_CungChieuKim thành công
    //      (và không bị va chạm), có thể phát âm thanh xoay khối.
}

//------------------------------------------------------
// Hoàn tác xoay CW vừa rồi (xoay ngược lại)
//  - Xoay ngược chiều kim đồng hồ 90 độ
//    dùng phép biến đổi:
//      (x, y) → (-y, x)
//  - Cập nhật lại TrangThai_Xoay
//------------------------------------------------------
void Khoi::HoanTac_QuayCungChieuKim()
{
    TrangThai_Xoay = (TrangThai_Xoay + 3) % 4; // tương đương -1 mod 4
    // Quay ngược lại 90 độ

    for (int i = 0; i < 4; ++i)
    {
        int X_Cu = DanhSach_OVuong[i].x;
        int Y_Cu = DanhSach_OVuong[i].y;

        int X_Moi = -Y_Cu;
        int Y_Moi = X_Cu;

        DanhSach_OVuong[i].x = X_Moi;
        DanhSach_OVuong[i].y = Y_Moi;
    }

    // TODO (Nguyễn Tiến Đạt – Âm thanh + hiệu ứng nổ):
    //      Nếu có logic hủy xoay (undo do va chạm),
    //      có thể thêm hiệu ứng/âm thanh báo xoay không thành công.
}
