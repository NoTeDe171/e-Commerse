﻿#pragma once
#include <array>
#include "CauHinh.hpp"

// Cấu trúc lưu trữ tọa độ nguyên 2 chiều (x: ngang, y: dọc)
struct ToaDo2i {
    int x; // Tọa độ theo trục ngang (cột)
    int y; // Tọa độ theo trục dọc (hàng)
};

// Lớp Khoi đại diện cho một khối rơi (I, O, T, S, Z, J, L)
class Khoi {
public:
    Khoi();
    Khoi(KieuKhoi Kieu_BanDau);
    // Tạo một khối với kiểu cụ thể (I, O, T, S, Z, J, L) được định nghĩa trong CauHinh.hpp

    void Dat_Lai(KieuKhoi Kieu_Moi);
    // Tái khởi tạo khối với kiểu mới (spawn khối mới),
    // đồng thời reset vị trí, trạng thái xoay, và hình dạng ô.

    void Dat_ViTri(int Cot_Moi, int Hang_Moi);
    // Đặt vị trí của khối trên bảng (theo tọa độ cột, hàng trên grid)

    void Di_Chuyen(int Delta_Cot, int Delta_Hang);
    // Di chuyển khối:
    //  - Delta_Cot  > 0: sang phải, < 0: sang trái
    //  - Delta_Hang > 0: đi xuống,   < 0: đi lên (hiếm khi dùng)

    void Quay_CungChieuKim();
    // Quay khối 90 độ theo chiều kim đồng hồ

    void HoanTac_QuayCungChieuKim();
    // Hoàn tác lần quay gần nhất (nếu sau khi quay bị va chạm, ta quay lại trạng thái cũ)

    // --------- Hàm getter dùng trong logic Board / vẽ ---------

    KieuKhoi Lay_Kieu() const { return Kieu; }
    // Trả về kiểu khối hiện tại (I, O, T, S, Z, J, L)

    int Lay_Cot() const { return Cot; }
    // Trả về tọa độ cột (x) của tâm khối trên bảng

    int Lay_Hang() const { return Hang; }
    // Trả về tọa độ hàng (y) của tâm khối trên bảng

    const std::array<ToaDo2i, 4>& Lay_CacOVuong() const { return DanhSach_OVuong; }
    // Trả về mảng 4 tọa độ local (dx, dy) của các ô vuông tạo thành khối,
    // tính tương đối so với tâm khối (0,0).

private:
    KieuKhoi Kieu;   // Kiểu khối hiện tại (I, O, T, S, Z, J, L)
    int      Cot;    // Vị trí cột (x) của tâm khối trên bảng
    int      Hang;   // Vị trí hàng (y) của tâm khối trên bảng

    int TrangThai_Xoay;
    // Trạng thái xoay hiện tại (0–3):
    //  0: không xoay
    //  1: xoay 90 độ
    //  2: xoay 180 độ
    //  3: xoay 270 độ

    std::array<ToaDo2i, 4> DanhSach_OVuong;
    // Tọa độ local của 4 ô vuông tạo thành khối, dựa trên vị trí (Cot, Hang).
    // Mỗi ô lưu (dx, dy) lệch so với tâm.

    std::array<ToaDo2i, 4> DanhSach_OVuong_Cu;
    // Lưu trữ trạng thái ô trước khi quay,
    // để có thể hoàn tác nếu cần (HoanTac_QuayCungChieuKim).

    void KhoiTao_HinhDang();
    // Khởi tạo DanhSach_OVuong dựa trên Kieu và TrangThai_Xoay.
    // Ví dụ:
    //  - Khối I: 4 ô nằm trên 1 dòng
    //  - Khối O: hình vuông 2x2
    //  - Khối T, S, Z, J, L: cấu trúc riêng

    void ApDung_QuayCungChieuKim();
    // Áp dụng phép quay 90 độ theo chiều kim đồng hồ lên DanhSach_OVuong,
    // sử dụng công thức biến đổi tọa độ (dx, dy).
};
